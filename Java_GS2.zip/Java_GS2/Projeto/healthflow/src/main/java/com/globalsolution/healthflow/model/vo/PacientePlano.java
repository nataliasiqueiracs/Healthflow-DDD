package com.globalsolution.healthflow.model.vo;

public class PacientePlano {
}
