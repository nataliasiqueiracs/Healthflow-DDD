package com.globalsolution.healthflow.model.vo;

import java.util.ArrayList;

public class Medico {

    private int idMedico;
    private String nome;
    private String crm;
    private String telefone;
    private String email;
    private String especialidade;
    private ArrayList<Paciente> pacientesAtendidos;

    public Medico(int idMedico, String nome, String crm, String telefone, String email, String especialidade) {
        this.idMedico = idMedico;
        this.nome = nome;
        this.crm = crm;
        this.telefone = telefone;
        this.email = email;
        this.especialidade = especialidade;
        this.pacientesAtendidos = new ArrayList<>();
    }

    public int getIdMedico() {
        return idMedico;
    }

    public void setIdMedico(int idMedico) {
        this.idMedico = idMedico;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCrm() {
        return crm;
    }

    public void setCrm(String crm) {
        this.crm = crm;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    public void atenderPaciente(Paciente paciente, String queixa) {
    //receber paciente
        //relatar queixa
        //definir diagnostico
    }

    public void realizarProcedimentosEmergenciais (Paciente paciente) {

    }

    public void adicionarPacienteAtendido(Paciente paciente) {
        this.pacientesAtendidos.add(paciente);
    }

    // Obtém a lista de pacientes atendidos
    public ArrayList<Paciente> getPacientesAtendidos() {
        return this.pacientesAtendidos;
    }

    // Exibe informações sobre o médico de pronto-socorro
    public void mostrarInformacoes() {
        System.out.println("Médico de Pronto-Socorro: " + nome);
        System.out.println("Especialidade: " + especialidade);
    }

    public void realizarDiagnostico(Diagnostico diagnostico) {

    }

}
