package com.globalsolution.healthflow.model.vo;

public class Diagnostico {

    private String diagnostico;

}
