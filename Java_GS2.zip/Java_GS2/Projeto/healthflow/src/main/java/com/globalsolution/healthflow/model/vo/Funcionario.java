package com.globalsolution.healthflow.model.vo;

import java.util.ArrayList;

public class Funcionario {

    private int idFuncionario;
    private String nome;
    private int cpf;
    private String endereco;
    private String telefone;
    private String email;
    private ArrayList<Paciente> pacientesAtendidos;

    public Funcionario(int idFuncionario, String nome, int cpf, String endereco, String telefone, String email) {
        this.idFuncionario = idFuncionario;
        this.nome = nome;
        this.cpf = cpf;
        this.endereco = endereco;
        this.telefone = telefone;
        this.email = email;
        this.pacientesAtendidos = new ArrayList<>();
    }

    public int getIdFuncionario() {
        return idFuncionario;
    }

    public void setIdFuncionario(int idFuncionario) {
        this.idFuncionario = idFuncionario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    //Método para adicionar um paciente à lista de pacientes atendidos pelo enfermeiro na triagem
    public void atenderPaciente(Paciente paciente) {

    }

    //Registrar informações sobre um atendimento a um paciente
    public void registrarAtendimento(Paciente paciente, String observacoes) {

    }

    //Obter a lista de pacientes atendidos pelo enfermeiro
    public ArrayList<Paciente> getPacientesAtendidos() {
        return new ArrayList<>(this.pacientesAtendidos);
    }

    //Método para encaminhar para o especialista
    public void encaminharParaEspecialista(ArrayList<Paciente> pacientes, Medico medico) {
        //lógica de encaminhamento
    }

}
