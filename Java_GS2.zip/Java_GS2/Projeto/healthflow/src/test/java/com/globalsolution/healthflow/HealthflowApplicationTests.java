package com.globalsolution.healthflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthflowApplicationTests {

	@Test
	void contextLoads() {
	}

}
